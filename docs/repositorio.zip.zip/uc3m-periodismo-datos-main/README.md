# uc3m-periodismo-datos


Clase del 14/09/20 **LAS URL** :

*https* indica el protocolo que está utilizando en este servicio de internet, y los :// separa el protocolo de la dirección. Esto está relacionado con el concepto de ***dominio***. Podemos pensar que github.com o uc3m.es son dominios, sin embargo, conviene saber que la dirección se compone de dos partes:
+ dominio
+  carpetas

Estas dos partes también vienen separadas de dos barras (//).

Si la lectura del dominio es de derecha a izquierda, en las carpetas es de izquierda a derecha.

El ordenador se refiere a sí mismo cuando lo usamos como **localhost** (127001)

